import service.MenuService;

public class Main {
    //AUTOR JHOJAN LOPEZ @JHOJYLOP
    public static void main(String[] args) {
        MenuService menuService = new MenuService();
        menuService.iniciar();
    }
}