import models.Cancion;

public class Main {
    public static void main(String[] args) {
        Cancion cancion1 = new Cancion();
        System.out.println(cancion1);
    }
}